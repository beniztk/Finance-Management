export default {
  plugins: {
    'postcss-rtlcss': {},
    tailwindcss: {},
    autoprefixer: {},
  },
};